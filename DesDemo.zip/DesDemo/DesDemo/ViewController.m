//
//  ViewController.m
//  DesDemo
//
//  Created by soyea on 16/9/13.
//  Copyright © 2016年 lyf. All rights reserved.
//

#import "ViewController.h"
#import "desFile.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *str = @"I love you";
    NSLog(@"加密：%@",[desFile encryptWithText:str]);//加密
    NSLog(@"解密：%@",[desFile decryptWithText:[desFile encryptWithText:str]]); //解密
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
