//
//  main.m
//  DesDemo
//
//  Created by soyea on 16/9/13.
//  Copyright © 2016年 lyf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
